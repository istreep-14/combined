### Constants and Enums

Schema
- schema_version: "1.0.0" (stored in Archives rows; bump on breaking column changes).

Sheet Names
```
Archives
Games
DailyTotals
DailyTotals_Active (legacy placeholder; consolidated into DailyTotals)
DailyTotals_Archive (legacy placeholder; consolidated into DailyTotals)
CallbackStats
Logs
```

Formats (normalized game categories)
```
bullet, blitz, rapid, daily,
live960, daily960,
threecheck, kingofthehill, bughouse, crazyhouse
```

Time Classes (allowed)
```
bullet, blitz, rapid, daily
```

Rules → Format mapping
- chess: use time_class as format (bullet/blitz/rapid/daily).
- chess960: live → live960, daily → daily960.
- threecheck/kingofthehill/bughouse/crazyhouse: format equals rules.
- oddschess exists but is not part of rating types used here.

Rated (boolean)
- Field `rated` is a boolean from the archive payload indicating whether the game changes ratings.

Result code → outcome mapping (player-centric)
```
win → win
agreed → draw
repetition → draw
stalemate → draw
insufficient → draw
50move → draw
timevsinsufficient → draw
checkmated → loss
timeout → loss
resigned → loss
abandoned → loss
kingofthehill → loss
threecheck → loss
bughousepartnerlose → loss
```

End Reason (normalized values used in `Games.end_reason`)
```
checkmate, resign, timeout, abandoned, stalemate, repetition, insufficient, 50move, agreed, timevsinsufficient, ''
```
Notes:
- Prefer PGN Termination text to derive end_reason; fallback to opponent result mapping.

Archive Status
```
active, inactive, active_pending
```

HTTP
- User-Agent: "ChessSheets/1.0 (AppsScript)"
- Conditional requests: If-None-Match with ETag.
- Backoff: exponential with jitter for 429 and 5xx.

Time Control Parsing
- Examples: "180+2" → base=180, increment=2; "300" → base=300, increment=0; "1/86400" → correspondence_time=86400.
- Pattern: `^\d+(?:\+\d+)?$` for live; `^1/\d+$` for daily correspondence.

Keys and Uniqueness
- Primary dedupe key: url (Games).
- Per-month cursor key: CURSOR_YYYY_MM_END_EPOCH in Script Properties.

Display Order (DailyTotals)
- Within a date: bullet, blitz, rapid, Main3, then others alphabetically.

Stats API format mapping (read-only)
```
chess_daily      -> daily
chess960_daily   -> daily960
chess_rapid      -> rapid
chess_blitz      -> blitz
chess_bullet     -> bullet
```

