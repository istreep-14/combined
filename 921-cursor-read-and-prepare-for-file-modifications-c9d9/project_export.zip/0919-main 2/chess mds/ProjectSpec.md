### Project Spec (Concise, New Structure)

Goal
- Backfill ~10k games; maintain daily totals; run callbacks over time for exactness; ingest new games ~5×/day; keep design simple, fast, and extensible for future per-game enrichments.

Doc Index
- Archive game schema: `ArchiveGameSchema.md`
- Data model and sheet columns: `DataModel.md`
- Constants and enums: `Constants.md`
- APIs and endpoints: `APIs.md`
- Triggers and operations: `TriggersOps.md`
- Setup and reset guide: `SetupReset.md`
- Performance and idempotency: `PerformanceIdempotency.md`
- Helpers contracts: `HelpersContracts.md`
- Ops log reference: see GameOpsLog below
GameOpsLog (append-only operational events)
```
timestamp, url, operation(ingest|write_games|write_meta|callback|rollover|daily_totals), status(ok|not_modified|error), http_code, details_json
```
Purpose: audit trails for troubleshooting; not used for analytics.

Sheets (minimal and intuitive)
- Games (single canonical table; newest at top)
- Metrics:
  - Archives (immutable months metadata)
  - CallbackStats (raw enriched stats per game; identity for both players; exact rating deltas)
  - Logs (structured)

Games Columns (stable order, lean)
```
url                       (required unique)
date                      (yyyy-MM-dd) from end_time
start_time                (local yyyy-MM-dd HH:mm:ss)
end_time                  (local yyyy-MM-dd HH:mm:ss)
time_control              (raw string)
rated                     (bool)
format                    (derived; see Constants)
my_color                  (white|black)
my_rating                 (postgame rating)
my_outcome                (win|draw|loss)
opponent_username         
opponent_rating           
end_reason                (derived)
```

GameMeta Columns (1 row per url; snapshot + long/raw fields)
```
url, is_live, rated, time_class, rules, format,
start_time_epoch, end_time_epoch, duration_seconds,
time_control, base_time, increment, correspondence_time,
eco_code, eco_url,
pgn, pgn_moves, tcn, initial_setup, fen,
my_username, my_color, my_rating, my_result, my_outcome, my_score,
opp_username, opp_color, opp_rating, opp_result, opp_outcome, opp_score,
accuracy_white, accuracy_black
```

Archives Columns
```
year, month, archive_url, status(active|inactive|active_pending),
etag, last_modified, last_checked,
game_count_api, game_count_ingested,
callback_completed, errors, schema_version
```

// Daily totals removed from project

Sorting Rules
- Games: newest first (insert new games at row 2). Backfill writes older months bottom-up or appends then reorders by inserting at top for incremental months.
- DailyTotals: chronological ascending by date, within date by format order [bullet, blitz, rapid, Main3, others alphabetical]. New dates appear at the end of existing dates.

Ingestion Strategy
- Backfill (~10k):
  - Iterate monthly archives; use ETag; transform to rows; write in chunks.
  - Build DailyTotals once at the end for performance and accuracy.
- Incremental (~5×/day):
  - Active month only; conditional GET with ETag.
  - Select new games with end_time after the month cursor; insert; update cursor.
  - Recompute DailyTotals for the full set (cheap) or targeted dates (optional optimization).

Callbacks (optional)
- If enabled later, store unified results in `GameMeta` or a dedicated sheet; `Games` remains lean.

Optional Future Enrichments (same pattern)
- Opening Analysis: external API per game; write raw sheet (OpeningAnalysis) keyed by url; add minimal lift columns to Games if desired.
- Game Data: external API per game; write raw sheet (GameData) keyed by url; add minimal lifts to Games.

Constants
```
Formats: bullet, blitz, rapid, daily, live960, daily960, threecheck, kingofthehill, bughouse, crazyhouse, Main3
Result→Outcome: win→win; agreed/repetition/stalemate/insufficient/50move/timevsinsufficient→draw; others→loss
Time format: yyyy-MM-dd HH:mm:ss (project TZ)
User-Agent: ChessSheets/1.0 (AppsScript)
Archives Status: active|inactive|active_pending
```

Helpers (contracts)
```
parseTimeControl, toLocalDateTimeStringFromUnixSeconds,
deriveFormat, computeDurationSeconds, pickPlayerColor, safe,
mapResultToOutcome, extractPgnHeader, writeRowsChunked
```

Triggers
```
Ingest Active Month: every ~3 hours
Rollover: daily ~01:10
Callbacks Enrichment: hourly, small batch
Other Enrichments: hourly/off-peak
```

Rechecks (Old Months)
- Inactive archives are treated immutable. Optionally schedule a monthly recheck (ETag only) to catch rare retro changes.

Logging
- Logs(level, code, message, context_json) for each orchestrator run: counts of added rows, HTTP codes (2xx/304/4xx/5xx), timing.

